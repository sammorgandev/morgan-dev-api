The following language text files are from Project Gutenberg, under the Project Gutenberg license

 - 84-0.txt (*Frankenstein* by Mary Shelley) https://www.gutenberg.org/files/84/84-0.txt
 - 35018-0.txt (*雲形紋章* by John Meade Falkner, translated by 林清俊) https://www.gutenberg.org/files/35018/35018-0.txt
 - 59765-0.txt (*Cítanka pro skoly obecné* by Jan Stastný, Jan Lepar and Josef Sokol) https://www.gutenberg.org/files/59765/59765-0.txt

graphemes.txt is derived from the Unicode Character Database file GraphemeBreakTest.txt available from https://www.unicode.org/Public/15.0.0/ucd/auxiliary/GraphemeBreakTest.txt used
under the [Unicode license](https://www.unicode.org/terms_of_use.html)

The following language text files are copied from Wikipedia, under the CC-BY-SA 3.0 license.

 - english.txt: https://en.wikipedia.org/wiki/English_language
 - korean.txt: https://ko.wikipedia.org/wiki/%ED%95%9C%EA%B5%AD%EC%96%B4
 - japanese.txt: https://ja.wikipedia.org/wiki/%E6%97%A5%E6%9C%AC%E8%AA%9E
 - hindi.txt: https://hi.wikipedia.org/wiki/%E0%A4%B9%E0%A4%BF%E0%A4%A8%E0%A5%8D%E0%A4%A6%E0%A5%80
 - mandarin.txt: https://zh.wikipedia.org/wiki/%E5%AE%98%E8%AF%9D
 - arabic.txt: https://ar.wikipedia.org/wiki/%D8%A7%D9%84%D9%84%D8%BA%D8%A9_%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9
 - russian.txt: https://ru.wikipedia.org/wiki/%D0%A0%D1%83%D1%81%D1%81%D0%BA%D0%B8%D0%B9_%D1%8F%D0%B7%D1%8B%D0%BA

 source_code.txt is from the Neovim source code, covered under the Apache 2.0
 license.

 - source_code.txt: https://github.com/veonim/neovim/blob/master/src/nvim/buffer.c

